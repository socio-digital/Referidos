<footer>
    <div class="container">
        <p>Derechos de autor &copy; <?php echo date("Y"); ?> socio digital. Todos los derechos reservados.</p>
        
        <iframe src="https://ls.sir.sportradar.com/betinaction/es" frameborder="0" width="100%" height="800px"></iframe>
        
    </div>
</footer>

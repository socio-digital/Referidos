<?php

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}



// Obtener todas las compras
$sql = "SELECT u.nombre, c.numero_comprado, c.monto, c.fecha 
        FROM compras c 
        JOIN usuarios u ON c.id_usuario = u.id 
        ORDER BY c.fecha DESC";
$resultado = $conn->query($sql);
$compras = $resultado->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Todas las Compras</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    

    <div class="container">
        <h2>Todas las Compras</h2>
        <table>
            <tr>
                <th>Usuario</th>
                <th>Número Comprado</th>
                <th>Monto</th>
                <th>Fecha</th>
            </tr>
            <?php foreach ($compras as $compra): ?>
            <tr>
                <td><?php echo htmlspecialchars($compra['nombre']); ?></td>
                <td><?php echo htmlspecialchars($compra['numero_comprado']); ?></td>
                <td><?php echo htmlspecialchars($compra['monto']); ?></td>
                <td><?php echo htmlspecialchars($compra['fecha']); ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>

  
</body>
</html>

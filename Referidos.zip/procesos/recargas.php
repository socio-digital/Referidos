<?php

include 'header.php';

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans+KR&display=swap" rel="stylesheet">
    <script src="https://kit.fontawesome.com/689ab320f1.js" crossorigin="anonymous"></script>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <link rel="stylesheet" href="estilos.css">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <title>Recargas</title>
</head>
<body class="imagenreserva">
    <header>
        <nav class="navbar navbar-expand-lg navbar-light"><div class="container-fluid"><a class="navbar-brand iconoMenu" href="../index.html">Recargas</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

<h1>medio de recargas </h1>

    </nav>
    </header>
    <div class="">
    <form action="" class="formulario">

        <h1 class="formulario__titulo">Cargar saldo</h1>
        <p class="formulario__parrafo">
        Llena este pequeño formulario.
        </p>

        <label for="cliente" class="formulario__label">¿Cuál es tu id?</label>
        <input
        id="cliente"
        type="text"
        class="formulario__input"
        placeholder="Indica cuál es tu id"
        />

        <label for="fecha" class="formulario__label"
    >Indica la fecha(solo presiona establecer)</label
        >
        <input
        id="fecha"
        type="date"
        class="formulario__input"
        pattern="[0-9]{4}-[0-9]{2}-[0-9]{2}"
        />

        <label for="hora" class="formulario__label"
        >Indica la hora(solo presiona establecer)</label
        >
        <input id="hora" type="time" class="formulario__input" />

        <label for="empleado" class="formulario__label"
        >moneda a recargar?</label
        >
        <select id="empleado" name="listaempleados" class="formulario__input">
        <option>USDT</option>
        <option>TRANSFERENCIA BANCARIA</option>
        </select>

        <label for="servicio" class="formulario__label"
        >¿Cuál es el monto que desea recargar?</label
        >
        <select id="servicio" name="listaservicios" class="formulario__input">
        <option>$500</option>
        <option>$1000</option>
        <option>$2000</option>
        <option>$30000</option>
        <option>$5000</option>
        <option>$10000</option>
        <option>$5 usdt</option>
        <option>$10 usdt</option>
        <option>$15 usdt</option>       
        <option>$20 usdt</option>
        <option>$25 usdt</option>
        <option>$30 usdt</option>
        <option>$50 usdt</option>
        <option>$100 usdt</option>
        </select>

        <div id="respuesta"></div>

        <button id="submit" class="formulario__submit">Confirmar</button>
    </form>
</div>
    </body>
    <div class="container">
    <footer class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top">
        <div class="col-md-4 d-flex align-items-center">
        <a href="/" class="mb-3 me-2 mb-md-0 text-muted text-decoration-none lh-1">
            <svg class="bi" width="30" height="24"><use xlink:href="#bootstrap"></use></svg>
        </a>
        <span class="mb-3 mb-md-0 text-muted">©2024/socio digital</span>
        </div>
        
        <ul class="nav col-md-4 justify-content-end list-unstyled d-flex">
        <li class="ms-3 secondary"><a class="text-muted" href="#"><img src="../img/iconos/facebook.svg" class="bi" width="24" height="24"></a></li>
        <li class="ms-3"><a class="text-muted" href="#"> <img src="../img/iconos/instagram.svg" class="bi" width="24" height="24"></a></li>
        <li class="ms-3"><a class="text-muted" href="#"><img src="../img/iconos/twitter.svg" class="bi" width="24" height="24"></a></li>
        </ul>
    </footer>
    </div>
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="recargas.js"></script>
</html>

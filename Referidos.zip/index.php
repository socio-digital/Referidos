<?php
session_start();
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

include 'header.php';
include 'db.php';


$id_usuario = $_SESSION['id'];
$enlace_referido = "https://referido-digital.000webhostapp.com/registro.php?ref=$id_usuario";
echo "<p>¡Invita a tus amigos a registrarse usando este enlace de referido y gana</p>";
echo "<p>$enlace_referido  </p>";


$id = $_SESSION['id'];
$nombre = $_SESSION['nombre'];

$sql = "SELECT saldo FROM usuarios WHERE id=$id";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $saldo = $row['saldo'];
} else {
    echo "Error al obtener el saldo";
}

echo "<h2>Bienvenido, $nombre</h2>";
echo "<p>Su saldo actual es: $saldo</p>";
echo "<p>tu id es: $id</p>";

include 'referidos.php';
// Formulario para realizar transferencias
echo "<h3>Realizar Transferencia</h3>";
echo "<form action='transferencia.php' method='post'>";
echo "<label for='id_destino'>ID de Usuario Destino:</label><br>";
echo "<input type='number' id='id_destino' name='id_destino' required><br>";
echo "<label for='monto'>Monto a Transferir:</label><br>";
echo "<input type='number' id='monto' name='monto' step='0.01' min='0.01' required><br>";
echo "<input type='submit' value='Transferir'>";
echo "</form>";

// Enlace para cerrar sesión

  
   include 'footer.php'; 
 




?>

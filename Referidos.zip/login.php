<?php
session_start();
if (isset($_SESSION['id'])) {
    // Si el usuario ya ha iniciado sesión, redirigirlo a la página principal
    header("Location: index.php");
    exit();
}

include 'db.php';

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $contraseña = $_POST['contraseña'];

    // Consultar la base de datos para verificar las credenciales
    $sql = "SELECT id, nombre, contraseña FROM usuarios WHERE nombre=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $nombre);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($contraseña, $row['contraseña'])) {
            // Inicio de sesión exitoso, crear una sesión para el usuario
            $_SESSION['id'] = $row['id'];
            $_SESSION['nombre'] = $row['nombre'];
            // Redirigir al usuario a la página principal
            header("Location: index.php");
            exit();
        } else {
            $error = "Contraseña incorrecta";
        }
    } else {
        $error = "Usuario no encontrado";
    }
}
?>

<?php include 'header.php'; ?>
<h2>Iniciar Sesión</h2>
<?php if (!empty($error)) { echo "<p>$error</p>"; } ?>
<form action="login.php" method="post">
    <label for="nombre">Nombre:</label><br>
    <input type="text" id="nombre" name="nombre" required><br>
    <label for="contraseña">Contraseña:</label><br>
    <input type="password" id="contraseña" name="contraseña" required><br>
    <input type="submit" value="Iniciar Sesión">
</form>
<?php include 'footer.php'; ?>

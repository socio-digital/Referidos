<?php

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}



$id_usuario = $_SESSION['id'];

// Obtener historial de transacciones
$sql_transacciones = "SELECT fecha, descripcion, monto FROM transacciones WHERE usuario_origen_id = $id_usuario OR usuario_destino_id = $id_usuario ORDER BY fecha DESC";
$result_transacciones = $conn->query($sql_transacciones);

// Obtener historial de referidos
$sql_referidos = "SELECT usuarios.nombre AS referido, referidos.fecha AS fecha_referido
                  FROM referidos
                  INNER JOIN usuarios ON referidos.usuario_referido_id = usuarios.id
                  WHERE referidos.usuario_referidor_id = $id_usuario
                  ORDER BY fecha_referido DESC";
$result_referidos = $conn->query($sql_referidos);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Historial</title>
    <style>
        /* Estilos CSS */
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: center;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Historial</h2>
        <h3>Historial de Transacciones</h3>
        <table>
            <thead>
                <tr>
                    <th>Fecha</th>
                    <th>Descripción</th>
                    <th>Monto</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result_transacciones->num_rows > 0) : ?>
                    <?php while ($row = $result_transacciones->fetch_assoc()) : ?>
                        <tr>
                            <td><?php echo $row['fecha']; ?></td>
                            <td><?php echo $row['descripcion']; ?></td>
                            <td><?php echo $row['monto']; ?></td>
                        </tr>
                    <?php endwhile; ?>
                <?php else : ?>
                    <tr><td colspan="3">No hay transacciones.</td></tr>
                <?php endif; ?>
            </

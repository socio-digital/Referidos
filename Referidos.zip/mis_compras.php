<?php

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}



$id_usuario = $_SESSION['id'];

// Obtener las compras del usuario
$sql = "SELECT numero_comprado, monto, fecha FROM compras WHERE id_usuario = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $id_usuario);
$stmt->execute();
$resultado = $stmt->get_result();
$compras = $resultado->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis Compras</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
   

    <div class="container">
        <h2>Mis Compras</h2>
        <table>
            <tr>
                <th>Número Comprado</th>
                <th>Monto</th>
                <th>Fecha</th>
            </tr>
            <?php foreach ($compras as $compra): ?>
            <tr>
                <td><?php echo htmlspecialchars($compra['numero_comprado']); ?></td>
                <td><?php echo htmlspecialchars($compra['monto']); ?></td>
                <td><?php echo htmlspecialchars($compra['fecha']); ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>

    
</body>
</html>

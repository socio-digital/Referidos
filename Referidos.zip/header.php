<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>socio digital</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <div class="container">
            <h1>Referido digital</h1>
            <nav>
                
                
                <ul>
                    <li><a href="index.php">Inicio</a></li>
                   
                    
                    <li><a href="procesos/recargas.php">Recargas</a></li>
                    <li><a href="procesos/retiros.php">Retiros</a></li>
                    
                    <li><a href="tragaperras.php">Tragaperras</a></li>
                    <li><a href="todas.php">Compra de números</a></li>
                    <li><a href="apuestas.php">apuestas</a></li>
                    
                    
                    <li><a href="logout.php">Cerrar Sesión</a></li>
                    
                </ul>
            </nav>
        </div>
      
    </header>
    <div class="container">
       

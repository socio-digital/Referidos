<?php
// Definir constantes para la configuración de la base de datos
define("DB_SERVER", "localhost");
define("DB_USERNAME", "id22172300_digital");
define("DB_PASSWORD", "55555Xl55555.");
define("DB_NAME", "id22172300_referido");

// Crear conexión
$conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Verificar la conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>

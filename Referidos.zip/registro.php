<?php
session_start();
if (isset($_SESSION['id'])) {
    // Si el usuario ya ha iniciado sesión, redirigirlo a la página principal
    header("Location: index.php");
    exit();
}

include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $contraseña = $_POST['contraseña'];
    $usuario_referidor_id = isset($_GET['ref']) ? $_GET['ref'] : null; // Obtener el ID del referidor si está presente en la URL

    // Verificar si el nombre de usuario ya está en uso
    $sql_nombre = "SELECT id FROM usuarios WHERE nombre='$nombre'";
    $result_nombre = $conn->query($sql_nombre);

    if ($result_nombre->num_rows > 0) {
        $error = "El nombre de usuario ya está en uso";
    } else {
        // Insertar el nuevo usuario en la base de datos
        $contraseña_hash = password_hash($contraseña, PASSWORD_DEFAULT);
        $sql_insertar_usuario = "INSERT INTO usuarios (nombre, contraseña, saldo) VALUES ('$nombre', '$contraseña_hash', 0)";

        if ($conn->query($sql_insertar_usuario) === TRUE) {
            // Registro exitoso, redirigir al usuario a la página de inicio de sesión
            $id_usuario_insertado = $conn->insert_id;

            // Insertar el referido en la tabla referidos si existe
            if ($usuario_referidor_id) {
                $sql_insertar_referido = "INSERT INTO referidos (usuario_referido_id, usuario_referidor_id) VALUES ('$id_usuario_insertado', '$usuario_referidor_id')";
                $conn->query($sql_insertar_referido);
            }

            header("Location: login.php");
            exit();
        } else {
            $error = "Error al registrar el usuario: " . $conn->error;
        }
    }
}
?>

<?php include 'header.php'; ?>
<h2>Registro de Usuario</h2>
<?php if (isset($error)) { echo "<p>$error</p>"; } ?>
<form action="registro.php<?php if(isset($_GET['ref'])) echo '?ref=' . $_GET['ref']; ?>" method="post">
    <label for="nombre">Nombre:</label><br>
    <input type="text" id="nombre" name="nombre" required><br>
    <label for="contraseña">Contraseña:</label><br>
    <input type="password" id="contraseña" name="contraseña" required><br>
    <input type="submit" value="Registrarse">
</form>
<?php include 'footer.php'; ?>

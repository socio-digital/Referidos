<?php

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}



$id_usuario = $_SESSION['id'];

// Obtener historial de referidos
$sql_referidos = "SELECT usuarios.nombre AS referido, referidos.fecha AS fecha_referido
                  FROM referidos
                  INNER JOIN usuarios ON referidos.usuario_referido_id = usuarios.id
                  WHERE referidos.usuario_referidor_id = $id_usuario
                  ORDER BY referidos.fecha DESC";

$result_referidos = $conn->query($sql_referidos);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Historial de Referidos</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h2>Historial de Referidos</h2>
        <table>
            <thead>
                <tr>
                    <th>Referido</th>
                    <th>Fecha de Referido</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result_referidos->num_rows > 0) : ?>
                    <?php while ($row = $result_referidos->fetch_assoc()) : ?>
                        <tr>
                            <td><?php echo $row['referido']; ?></td>
                            <td><?php echo $row['fecha_referido']; ?></td>
                        </tr>
                    <?php endwhile; ?>
                <?php else : ?>
                    <tr><td colspan="2">No hay referidos.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>

<footer>
    <div class="container">
        <p>Derechos de autor &copy; <?php echo date("Y"); ?> Referido-digital. Todos los derechos reservados.</p>
    </div>
</footer>

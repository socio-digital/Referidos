<?php
session_start();
if (isset($_SESSION['id'])) {
    // Si el usuario ya ha iniciado sesión, redirigirlo a la página principal
    header("Location: index.php");
    exit();
}

include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $contraseña = $_POST['contraseña'];

    // Verificar si el nombre de usuario ya está en uso
    $sql = "SELECT id FROM usuarios WHERE nombre='$nombre'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $error = "El nombre de usuario ya está en uso";
    } else {
        // Insertar el nuevo usuario en la base de datos
        $contraseña_hash = password_hash($contraseña, PASSWORD_DEFAULT);
        $sql = "INSERT INTO usuarios (nombre, contraseña, saldo) VALUES ('$nombre', '$contraseña_hash', 0)";
        
        if ($conn->query($sql) === TRUE) {
            // Registro exitoso, redirigir al usuario a la página de inicio de sesión
            header("Location: login.php");
            exit();
        } else {
            $error = "Error al registrar el usuario: " . $conn->error;
        }
    }
}
?>

<?php
session_start();
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

include 'db.php';

$id_usuario = $_SESSION['id'];

// Manejar la realización de apuestas
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['partido_id']) && isset($_POST['equipo_ganador_id']) && isset($_POST['monto'])) {
    $usuario_id = $_SESSION['id'];
    $partido_id = $_POST['partido_id'];
    $equipo_ganador_id = $_POST['equipo_ganador_id'];
    $monto = $_POST['monto'];

    // Verificar si el usuario tiene suficiente saldo
    $sql = "SELECT saldo FROM usuarios WHERE id=$usuario_id";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $saldo = $row['saldo'];
        if ($saldo >= $monto) {
            // Deducir el monto del saldo del usuario
            $nuevo_saldo = $saldo - $monto;
            $sql = "UPDATE usuarios SET saldo=$nuevo_saldo WHERE id=$usuario_id";
            if ($conn->query($sql) === TRUE) {
                // Insertar la apuesta en la base de datos
                $sql = "INSERT INTO apuestas (usuario_id, partido_id, equipo_ganador_id, monto) VALUES ($usuario_id, $partido_id, $equipo_ganador_id, $monto)";
                if ($conn->query($sql) === TRUE) {
                    $mensaje = "Apuesta realizada con éxito";
                } else {
                    $mensaje = "Error al realizar la apuesta: " . $conn->error;
                }
            } else {
                $mensaje = "Error al actualizar el saldo: " . $conn->error;
            }
        } else {
            $mensaje = "Saldo insuficiente";
        }
    } else {
        $mensaje = "Error al obtener el saldo";
    }
}

// Obtener la lista de partidos
$sql = "SELECT p.*, e1.nombre as equipo1, e2.nombre as equipo2 
        FROM partidos p
        JOIN equipos e1 ON p.equipo1_id = e1.id
        JOIN equipos e2 ON p.equipo2_id = e2.id";
$partidos = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hacer Apuesta</title>
    <link rel="stylesheet" href="new-styles.css">
</head>
<body>
    <?php include 'header.php'; ?>

    <div class="container">
        <h2>Hacer Apuesta</h2>
        <h3>100% ganancia y 100% perdida</h3>
        <?php if (isset($mensaje)) { echo "<p>$mensaje</p>"; } ?>
        <form action="apuestas.php" method="post">
            <label for="partido_id">Partido:</label><br>
            <select id="partido_id" name="partido_id" required>
                <?php while($partido = $partidos->fetch_assoc()) { ?>
                    <option value="<?php echo $partido['id']; ?>"><?php echo $partido['equipo1'] . " vs " . $partido['equipo2'] . " - " . $partido['fecha']; ?></option>
                <?php } ?>
            </select><br>
            <label for="equipo_ganador_id">Tu Equipo:</label><br>
            <select id="equipo_ganador_id" name="equipo_ganador_id" required>
                <?php 
                $partidos->data_seek(0); // Resetear el puntero del resultado
                while($partido = $partidos->fetch_assoc()) { ?>
                    <option value="<?php echo $partido['equipo1_id']; ?>"><?php echo $partido['equipo1']; ?></option>
                    <option value="<?php echo $partido['equipo2_id']; ?>"><?php echo $partido['equipo2']; ?></option>
                <?php } ?>
            </select><br>
            <label for="monto">Monto a Apostar:</label><br>
            <input type="number" id="monto" name="monto" step="0.01" min="0.01" required><br>
            <input type="submit" value="Apostar">
        </form>
    </div>
    <?php include 'historial_apuestas.php'; ?>
    <?php include 'footer2.php'; ?>
</body>
</html>

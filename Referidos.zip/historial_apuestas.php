<?php

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}



$id_usuario = $_SESSION['id'];

// Obtener el historial de apuestas del usuario
$sql = "SELECT a.*, p.fecha AS fecha_partido, p.equipo1_id, p.equipo2_id, e1.nombre AS equipo1, e2.nombre AS equipo2
        FROM apuestas a
        JOIN partidos p ON a.partido_id = p.id
        JOIN equipos e1 ON p.equipo1_id = e1.id
        JOIN equipos e2 ON p.equipo2_id = e2.id
        WHERE a.usuario_id = $id_usuario
        ORDER BY a.fecha DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Historial de Apuestas</title>
    <link rel="stylesheet" href="new-styles.css">
</head>
<body>
  

    <div class="container">
        <h2>Historial de Apuestas</h2>
        <?php if ($result->num_rows > 0) { ?>
            <table>
                <thead>
                    <tr>
                        <th>Fecha de Apuesta</th>
                        <th>Partido</th>
                        <th>Fecha del Partido</th>
                        <th>Equipo Apostado</th>
                        <th>Monto</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = $result->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo $row['fecha']; ?></td>
                            <td><?php echo $row['equipo1'] . " vs " . $row['equipo2']; ?></td>
                            <td><?php echo $row['fecha_partido']; ?></td>
                            <td>
                                <?php 
                                if ($row['equipo_ganador_id'] == $row['equipo1_id']) {
                                    echo $row['equipo1'];
                                } else if ($row['equipo_ganador_id'] == $row['equipo2_id']) {
                                    echo $row['equipo2'];
                                } else {
                                    echo "Equipo no identificado";
                                }
                                ?>
                            </td>
                            <td><?php echo $row['monto']; ?></td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        <?php } else { ?>
            <p>No has realizado ninguna apuesta.</p>
        <?php } ?>
    </div>

    
</body>
</html>


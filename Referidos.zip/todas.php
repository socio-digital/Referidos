<?php
session_start();
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

include 'db.php';

$id_usuario = $_SESSION['id'];

// Obtener el saldo actual del usuario
$sql = "SELECT saldo FROM usuarios WHERE id = $id_usuario";
$resultado = $conn->query($sql);

if ($resultado->num_rows > 0) {
    $fila = $resultado->fetch_assoc();
    $saldo = $fila['saldo'];
} else {
    $saldo = "Error al obtener el saldo";
}

// Manejar la compra de números
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $numero_comprado = $_POST['numero'];
    $monto = $_POST['monto'];

    if ($saldo >= $monto) {
        $nuevo_saldo = $saldo - $monto;

        // Actualizar el saldo del usuario
        $sql = "UPDATE usuarios SET saldo = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('di', $nuevo_saldo, $id_usuario);
        if ($stmt->execute()) {
            // Registrar la compra
            $sql = "INSERT INTO compras (id_usuario, numero_comprado, monto) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('iid', $id_usuario, $numero_comprado, $monto);
            if ($stmt->execute()) {
                $mensaje = "Compra realizada con éxito. Tu nuevo saldo es: $nuevo_saldo";
                $saldo = $nuevo_saldo; // Actualizar el saldo mostrado
            } else {
                $mensaje = "Error al registrar la compra: " . $stmt->error;
            }
        } else {
            $mensaje = "Error al actualizar el saldo: " . $stmt->error;
        }
    } else {
        $mensaje = "Saldo insuficiente para realizar la compra.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Compra de Números</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php include 'header.php'; ?>

    <div class="container">
        <h2>Compra de Números</h2>
        <p>Tu saldo actual es: <span id="saldo"><?php echo $saldo; ?></span></p>
        <form action="todas.php" method="post">
            <label for="numero">Número a comprar:</label>
            <input type="number" id="numero" name="numero" min="1" max="100" required>
            <label for="monto">Monto:</label>
            <input type="number" id="monto" name="monto" min="1" max="<?php echo $saldo; ?>" required>
            <input type="submit" value="Comprar">
        </form>
        <?php if (isset($mensaje)) { echo "<p>$mensaje</p>"; } ?>
    </div>
    <?php include 'mis_compras.php'; ?>
    <?php include 'todas_compras.php'; ?>
    <?php include 'footer.php'; ?>
</body>
</html>

document.getElementById('spin-button').addEventListener('click', function() {
    var slotReel = document.getElementById('slot-reel');
    var resultDiv = document.getElementById('result');
    var saldoElement = document.getElementById('saldo');
    var saldo = parseFloat(saldoElement.textContent);

    // Cost of each spin
    const cost = 10;
    if (saldo < cost) {
        resultDiv.textContent = 'Saldo insuficiente para jugar';
        return;
    }

    // Deduct cost
    saldo -= cost;
    saldoElement.textContent = saldo.toFixed(2);

    // Ocultar resultado anterior
    resultDiv.textContent = '';

    // Generar resultados aleatorios para cada carrete
    var reel1 = Math.floor(Math.random() * 3) + 1;
    var reel2 = Math.floor(Math.random() * 3) + 1;
    var reel3 = Math.floor(Math.random() * 3) + 1;

    // Mostrar animación de los carretes girando
    var spinInterval = setInterval(function() {
        reel1 = (reel1 % 3) + 1;
        reel2 = (reel2 % 3) + 1;
        reel3 = (reel3 % 3) + 1;

        slotReel.innerHTML = `
            <img src="images/${reel1}.jpg" alt="Slot 1">
            <img src="images/${reel2}.jpg" alt="Slot 2">
            <img src="images/${reel3}.jpg" alt="Slot 3">
        `;
    }, 100);

    // Detener la animación después de 10 segundos
    setTimeout(function() {
        clearInterval(spinInterval);

        // Determinar el resultado
        if (reel1 === reel2 && reel2 === reel3) {
            const prize = cost * 10; // Ejemplo de premio multiplicador
            saldo += prize;
            saldoElement.textContent = saldo.toFixed(2);
            resultDiv.textContent = `¡Felicidades! Has ganado ${prize.toFixed(2)}. ¡Recibes un gran premio!`;
        } else {
            resultDiv.textContent = 'Lo siento, no has ganado. Inténtalo de nuevo.';
        }

        // Actualizar saldo en la base de datos
        fetch('update_saldo.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ saldo: saldo })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                console.log('Saldo actualizado correctamente');
            } else {
                console.error('Error al actualizar el saldo: ' + data.error);
            }
        });
    }, 5000); // Duración de 10 segundos
});

<?php
session_start();
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

include 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_usuario_origen = $_SESSION['id'];
    $id_usuario_destino = $_POST['id_destino'];
    $monto = $_POST['monto'];

    // Verificar si el usuario destino existe
    $sql = "SELECT saldo FROM usuarios WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id_usuario_destino);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $saldo_destino = $row['saldo'];

        // Verificar si el usuario origen tiene suficiente saldo para transferir
        $sql = "SELECT saldo FROM usuarios WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("i", $id_usuario_origen);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $saldo_origen = $row['saldo'];

            if ($saldo_origen >= $monto) {
                // Realizar la transferencia dentro de una transacción
                $conn->begin_transaction();

                $nuevo_saldo_origen = $saldo_origen - $monto;
                $nuevo_saldo_destino = $saldo_destino + $monto;

                $sql1 = "UPDATE usuarios SET saldo=? WHERE id=?";
                $stmt1 = $conn->prepare($sql1);
                $stmt1->bind_param("di", $nuevo_saldo_origen, $id_usuario_origen);

                $sql2 = "UPDATE usuarios SET saldo=? WHERE id=?";
                $stmt2 = $conn->prepare($sql2);
                $stmt2->bind_param("di", $nuevo_saldo_destino, $id_usuario_destino);

                if ($stmt1->execute() && $stmt2->execute()) {
                    $conn->commit();
                    echo "Transferencia realizada con éxito";
                    header("Location: index.php");
                } else {
                    $conn->rollback();
                    echo "Error al realizar la transferencia";
                }
            } else {
                echo "Saldo insuficiente para realizar la transferencia";
            }
        } else {
            echo "Error al obtener el saldo del usuario origen";
        }
    } else {
        echo "El usuario destino no existe";
    }
}
?>

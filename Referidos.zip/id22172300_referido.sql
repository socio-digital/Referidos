-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 18-05-2024 a las 03:53:25
-- Versión del servidor: 10.5.20-MariaDB
-- Versión de PHP: 7.3.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `id22172300_referido`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `apuestas`
--

CREATE TABLE `apuestas` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) NOT NULL,
  `partido_id` int(11) NOT NULL,
  `equipo_ganador_id` int(11) NOT NULL,
  `monto` decimal(10,2) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `apuestas`
--

INSERT INTO `apuestas` (`id`, `usuario_id`, `partido_id`, `equipo_ganador_id`, `monto`, `fecha`) VALUES
(22, 3, 4, 12, 400.00, '2024-05-18 02:32:43'),
(23, 1, 2, 9, 200.00, '2024-05-18 02:44:08'),
(24, 4, 1, 7, 1000.00, '2024-05-18 03:42:36');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `compras`
--

CREATE TABLE `compras` (
  `id` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `numero_comprado` int(11) NOT NULL,
  `monto` decimal(10,2) NOT NULL,
  `fecha` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `compras`
--

INSERT INTO `compras` (`id`, `id_usuario`, `numero_comprado`, `monto`, `fecha`) VALUES
(1, 4, 100, 200.00, '2024-05-16 23:02:49'),
(2, 6, 27, 250.00, '2024-05-17 00:08:15'),
(3, 1, 22, 300.00, '2024-05-17 22:00:28');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `equipos`
--

CREATE TABLE `equipos` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `equipos`
--

INSERT INTO `equipos` (`id`, `nombre`) VALUES
(1, 'River Plate'),
(2, 'Boca Junior'),
(3, 'San Martín  (sj)'),
(4, 'Vélez sarfield'),
(5, 'Temperley'),
(6, 'Gimnasia la Plata'),
(7, 'Rivadavia'),
(8, 'Godoy Cruz'),
(9, 'Belgrano de Cordoba'),
(10, 'Defenza y Justicia'),
(11, 'Inst. Cordoba'),
(12, 'Santa fe');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `partidos`
--

CREATE TABLE `partidos` (
  `id` int(11) NOT NULL,
  `equipo1_id` int(11) NOT NULL,
  `equipo2_id` int(11) NOT NULL,
  `fecha` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `partidos`
--

INSERT INTO `partidos` (`id`, `equipo1_id`, `equipo2_id`, `fecha`) VALUES
(1, 7, 8, '2024-05-18 15:29:21'),
(2, 1, 9, '2024-05-18 18:30:09'),
(3, 10, 6, '2024-05-18 20:00:09'),
(4, 11, 12, '2024-05-18 20:32:33');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `referidos`
--

CREATE TABLE `referidos` (
  `id` int(11) NOT NULL,
  `usuario_referido_id` int(11) NOT NULL,
  `usuario_referidor_id` int(11) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `referidos`
--

INSERT INTO `referidos` (`id`, `usuario_referido_id`, `usuario_referidor_id`, `fecha`) VALUES
(1, 2, 1, '2024-05-14 18:52:53'),
(2, 3, 1, '2024-05-15 00:38:26'),
(3, 4, 1, '2024-05-15 04:42:42'),
(4, 5, 1, '2024-05-15 22:06:03'),
(5, 6, 5, '2024-05-15 22:06:58'),
(6, 7, 1, '2024-05-15 22:09:03'),
(7, 8, 3, '2024-05-16 01:44:35'),
(8, 9, 6, '2024-05-16 19:21:23'),
(9, 10, 1, '2024-05-16 21:33:52');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `transacciones`
--

CREATE TABLE `transacciones` (
  `id` int(11) NOT NULL,
  `usuario_origen_id` int(11) NOT NULL,
  `usuario_destino_id` int(11) NOT NULL,
  `monto` decimal(10,2) NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `saldo` decimal(10,2) NOT NULL,
  `contraseña` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre`, `saldo`, `contraseña`) VALUES
(1, 'fupaco9@gmail.com', 1329.00, '$2y$10$0LZSq9sxDlGPiVrYWWsuxewErtOTZ4QYJc0KgF6yaRsb.IeRRtClO'),
(2, 'Pp@gmail.com', 1940.00, '$2y$10$XrXwL4u9YkjVQHcU4mHTNer5jWQQR9CAJ2F5pUzdTNVvy5UPwrdgm'),
(3, 'pacocsd@gmail.com', 40.00, '$2y$10$jaI.Omw2Uwtkb91d0d8CNenJ3dWUXh0bZABn6Dmt5mBeg16gu8jwu'),
(4, 'ozero', 860.00, '$2y$10$Z4Gx6Ct6TCZsY3UljzZYWuyH2rfzZoWM9UutQ1Gs1.QYoay9VHulu'),
(5, 'loco@gmail.com', 519.00, '$2y$10$ezKz1dX6gmTgbnHU6Lix6.iVXEtma092ouAJ5pwX2Y5wj84Ic8/x.'),
(6, 'willy22@gmail.com', 4.00, '$2y$10$hI7hiULgLxnjOgRYi2mUtOWzKQJnozC1BMXWHNuMPz0xvLUO5yqQK'),
(7, 'Eliaslucero289', 180.00, '$2y$10$5d4G9jHphOX0XWvYgMlbL.dc80MiLsupwFIgOu/eWveyVvrsnArnm'),
(8, 'perro@gmail.com', 0.00, '$2y$10$9J3DK0f3VfWKUhU1fIhyhekMaSS4X3KkEvi98JGK83T9Qc7JEnvky'),
(9, 'Lian123', 1370.00, '$2y$10$2GE7TeiqUISZKtw8w63oZ.0dbdSTyswva2oBqNFM4BhObp9NHy0VW'),
(10, 'csd1@gmail.com', 139.00, '$2y$10$Y.gNsus9ILda74D47R6SM.aLAvvcJolw0izdDTA.fp.XuMUUZkkvC');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `apuestas`
--
ALTER TABLE `apuestas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_id` (`usuario_id`),
  ADD KEY `partido_id` (`partido_id`),
  ADD KEY `equipo_ganador_id` (`equipo_ganador_id`);

--
-- Indices de la tabla `compras`
--
ALTER TABLE `compras`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Indices de la tabla `equipos`
--
ALTER TABLE `equipos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `partidos`
--
ALTER TABLE `partidos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `equipo1_id` (`equipo1_id`),
  ADD KEY `equipo2_id` (`equipo2_id`);

--
-- Indices de la tabla `referidos`
--
ALTER TABLE `referidos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_referido_id` (`usuario_referido_id`),
  ADD KEY `usuario_referidor_id` (`usuario_referidor_id`);

--
-- Indices de la tabla `transacciones`
--
ALTER TABLE `transacciones`
  ADD PRIMARY KEY (`id`),
  ADD KEY `usuario_origen_id` (`usuario_origen_id`),
  ADD KEY `usuario_destino_id` (`usuario_destino_id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `apuestas`
--
ALTER TABLE `apuestas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT de la tabla `compras`
--
ALTER TABLE `compras`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `equipos`
--
ALTER TABLE `equipos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `partidos`
--
ALTER TABLE `partidos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `referidos`
--
ALTER TABLE `referidos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `transacciones`
--
ALTER TABLE `transacciones`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `apuestas`
--
ALTER TABLE `apuestas`
  ADD CONSTRAINT `apuestas_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `apuestas_ibfk_2` FOREIGN KEY (`partido_id`) REFERENCES `partidos` (`id`),
  ADD CONSTRAINT `apuestas_ibfk_3` FOREIGN KEY (`equipo_ganador_id`) REFERENCES `equipos` (`id`);

--
-- Filtros para la tabla `compras`
--
ALTER TABLE `compras`
  ADD CONSTRAINT `compras_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `partidos`
--
ALTER TABLE `partidos`
  ADD CONSTRAINT `partidos_ibfk_1` FOREIGN KEY (`equipo1_id`) REFERENCES `equipos` (`id`),
  ADD CONSTRAINT `partidos_ibfk_2` FOREIGN KEY (`equipo2_id`) REFERENCES `equipos` (`id`);

--
-- Filtros para la tabla `referidos`
--
ALTER TABLE `referidos`
  ADD CONSTRAINT `referidos_ibfk_1` FOREIGN KEY (`usuario_referido_id`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `referidos_ibfk_2` FOREIGN KEY (`usuario_referidor_id`) REFERENCES `usuarios` (`id`);

--
-- Filtros para la tabla `transacciones`
--
ALTER TABLE `transacciones`
  ADD CONSTRAINT `transacciones_ibfk_1` FOREIGN KEY (`usuario_origen_id`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `transacciones_ibfk_2` FOREIGN KEY (`usuario_destino_id`) REFERENCES `usuarios` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

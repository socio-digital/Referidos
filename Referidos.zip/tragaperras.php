<?php
session_start();
if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

include 'db.php';

$id_usuario = $_SESSION['id'];

// Obtener el saldo actual del usuario
$sql = "SELECT saldo FROM usuarios WHERE id = $id_usuario";
$resultado = $conn->query($sql);

if ($resultado->num_rows > 0) {
    $fila = $resultado->fetch_assoc();
    $saldo = $fila['saldo'];
} else {
    $saldo = "Error al obtener el saldo";
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Juego de Tragaperras</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php include 'header.php'; ?>

    <div class="container">
        <h2>Juego de Tragaperras</h2>
        <p>Tu saldo actual es: <span id="saldo"><?php echo $saldo; ?></span></p>
        <div id="slot-machine" class="game">
            <p>Máquina tragaperras</p>
            <p>¿Estás listo para ganar?</p>
            <button id="spin-button">Jugar</button>
            <div id="slot-reel" class="slot-reel">
                <img src="images/1.jpg" alt="Slot 1">
                <img src="images/2.jpg" alt="Slot 2">
                <img src="images/3.jpg" alt="Slot 3">
            </div>
            <div id="result"></div>
        </div>
    </div>

    <?php include 'footer.php'; ?>

    <script src="script.js"></script>
</body>
</html>

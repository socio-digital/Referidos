<?php
session_start();
if (!isset($_SESSION['id'])) {
    header("Location: index.php");
    exit();
}

include 'db.php';

$id_usuario = $_SESSION['id'];

$sql = "SELECT usuarios.nombre AS referido, referidos.fecha AS fecha_referido
        FROM referidos
        INNER JOIN usuarios ON referidos.usuario_referido_id = usuarios.id
        WHERE referidos.usuario_referidor_id = $id_usuario";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Historial de Referidos</title>
    <link rel="stylesheet" href="styles.css">
    
</head>
<body>
    <div class="container">
        <h2>Historial de Referidos</h2>
        <table>
            <thead>
                <tr>
                    <th>Referido</th>
                    <th>Fecha de Referido</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['referido'] . "</td>";
                        echo "<td>" . $row['fecha_referido'] . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='2'>No hay referidos.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>

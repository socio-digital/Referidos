<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Juego de Apuestas</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
  

    <div class="container">
        <h2>Juego de Apuestas</h2>
        <div id="game-container" class="game">
            <p>¡Bienvenido al nuevo juego de apuestas!</p>
            <p>¿Estás listo para ganar grandes premios?</p>
            <button id="play-button">Jugar</button>
            <div id="dice-container">
                <img id="dice-img" src="dice-1.png" alt="Dado" width="100">
            </div>
            <div id="result"></div>
        </div>
    </div>

 

    <script>
        document.getElementById('play-button').addEventListener('click', function() {
            var diceImg = document.getElementById('dice-img');
            var resultDiv = document.getElementById('result');

            // Ocultar resultado anterior
            resultDiv.textContent = '';

            // Mostrar animación del dado
            var rollInterval = setInterval(function() {
                var randomNum = Math.floor(Math.random() * 6) + 1;
                diceImg.src = 'dice-' + randomNum + '.png';
            }, 100);

            // Detener la animación después de un tiempo aleatorio
            setTimeout(function() {
                clearInterval(rollInterval);

                // Determinar el resultado
                var randomNumber = Math.floor(Math.random() * 6) + 1;
                if (randomNumber === 6) {
                    resultDiv.textContent = '¡Felicidades! Ganaste. Has obtenido ' + (5 * <?php echo $apuesta; ?>) + ' unidades de saldo.';
                } else {
                    resultDiv.textContent = 'Lo siento, perdiste. Inténtalo de nuevo.';
                }
            }, Math.random() * 3000 + 1000); // Tiempo aleatorio entre 1 y 4 segundos
        });
    </script>
</body>
</html>

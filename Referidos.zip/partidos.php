<?php

if (!isset($_SESSION['id'])) {
    header("Location: login.php");
    exit();
}

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultados</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php include 'header.php'; ?>

    <div class="container">
        
          <iframe src="https://ls.sir.sportradar.com/betinaction/es" frameborder="0" width="100%" height="800px"></iframe>
        
    </div>

   <?php include 'footer.php'; ?>
</body>
</html>


        
            
          
            
            